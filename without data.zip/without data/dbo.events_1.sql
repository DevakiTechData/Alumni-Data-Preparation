USE SluAlumniDatabase;
GO

CREATE TABLE dbo.events_1 (
  event_id                  UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_events_1_id DEFAULT NEWID(), -- (1) PK
  event_name                VARCHAR(200)   NOT NULL,                                              -- (2)
  event_type                VARCHAR(80)    NOT NULL,                                              -- (3) Career Fair/Webinar/Workshop/Meetup/Guest Lecture
  event_theme               VARCHAR(160)   NULL,                                                  -- (4)
  event_description         NVARCHAR(MAX)  NULL,                                                  -- (5)
  start_datetime            DATETIME2      NOT NULL,                                              -- (6)
  end_datetime              DATETIME2      NOT NULL,                                              -- (7)
  timezone                  VARCHAR(60)    NULL,                                                  -- (8)
  delivery_mode             VARCHAR(20)    NULL,                                                  -- (9) In-person / Virtual / Hybrid
  location_venue            VARCHAR(160)   NULL,                                                  -- (10)
  location_city             VARCHAR(80)    NULL,                                                  -- (11)
  location_state            VARCHAR(80)    NULL,                                                  -- (12)
  location_country          VARCHAR(80)    NULL,                                                  -- (13)
  organizer_unit            VARCHAR(160)   NULL,                                                  -- (14) Alumni Office / Career Services / Dept
  organizer_contact_email   VARCHAR(120)   NULL,                                                  -- (15)
  capacity                  INT            NULL,                                                  -- (16)
  rsvp_required             BIT            NOT NULL DEFAULT 0,                                    -- (17)
  registrations_count       INT            NOT NULL DEFAULT 0,                                    -- (18)
  attendees_count           INT            NOT NULL DEFAULT 0,                                    -- (19)
  feedback_score_avg        DECIMAL(3,2)  NULL,                                                   -- (20) 1.00�5.00 typical

  CONSTRAINT PK_events_1 PRIMARY KEY (event_id),

  -- Controlled vocabularies
  CONSTRAINT chk_event_type CHECK (
      event_type IN ('Career Fair','Webinar','Workshop','Meetup','Guest Lecture')
  ),
  CONSTRAINT chk_delivery_mode CHECK (
      delivery_mode IN ('In-person','Virtual','Hybrid') OR delivery_mode IS NULL
  ),

  -- Data quality checks
  CONSTRAINT chk_dates_order CHECK (end_datetime >= start_datetime),
  CONSTRAINT chk_capacity_nonneg CHECK (capacity IS NULL OR capacity >= 0),
  CONSTRAINT chk_regs_nonneg CHECK (registrations_count >= 0),
  CONSTRAINT chk_attendees_nonneg CHECK (attendees_count >= 0),
  CONSTRAINT chk_attendees_le_regs CHECK (attendees_count <= registrations_count)
);
GO
