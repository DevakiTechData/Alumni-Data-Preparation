﻿USE SluAlumniDatabase;
GO

CREATE TABLE dbo.alumni_1 (
  alumni_id                UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_alumni_1_id DEFAULT NEWID(), -- PK
  student_id               UNIQUEIDENTIFIER NOT NULL,           -- FK → students_1(student_id), one-to-one
  current_employer_id      UNIQUEIDENTIFIER NULL,               -- FK → employers_1(employer_id)
  current_title            VARCHAR(160)  NULL,
  years_experience         DECIMAL(4,1)  NULL,                  -- e.g., 3.5
  career_stage             VARCHAR(40)   NULL,                  -- Early / Mid / Senior / Lead (optional)
  skills_primary           TEXT          NULL,                  -- comma/JSON list
  skills_secondary         TEXT          NULL,
  certifications           TEXT          NULL,
  achievements             TEXT          NULL,
  mentoring_interest       BIT           NOT NULL DEFAULT 0,
  volunteering_interest    BIT           NOT NULL DEFAULT 0,
  is_active_member         BIT           NOT NULL DEFAULT 1,    -- active in alumni network
  last_engagement_date     DATE          NULL,
  profile_visibility       VARCHAR(20)   NULL,                  -- Public / SLU-only / Private
  preferred_contact_method VARCHAR(30)   NULL,                  -- Email / LinkedIn / Phone
  preferred_time_zone      VARCHAR(60)   NULL,                  -- e.g., America/Chicago
  portfolio_url            VARCHAR(255)  NULL,
  github_url               VARCHAR(255)  NULL,
  created_at               DATETIME      NOT NULL DEFAULT GETDATE(),

  CONSTRAINT PK_alumni_1 PRIMARY KEY (alumni_id),

  -- enforce one-to-one with students
  CONSTRAINT UQ_alumni_1_student UNIQUE (student_id),

  -- foreign keys
  CONSTRAINT FK_alumni_1_student FOREIGN KEY (student_id)
      REFERENCES dbo.students_1(student_id)
      ON UPDATE CASCADE
      ON DELETE CASCADE,

  CONSTRAINT FK_alumni_1_employer FOREIGN KEY (current_employer_id)
      REFERENCES dbo.employers_1(employer_id)
      ON UPDATE CASCADE
      ON DELETE SET NULL,

  -- controlled vocab constraints
  CONSTRAINT chk_profile_visibility CHECK (
      profile_visibility IN ('Public','SLU-only','Private') OR profile_visibility IS NULL
  ),
  CONSTRAINT chk_contact_method CHECK (
      preferred_contact_method IN ('Email','LinkedIn','Phone') OR preferred_contact_method IS NULL
  )
);
GO
