USE SluAlumniDatabase;
GO
CREATE TABLE dbo.employers_1 (
  employer_id                UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_employers_1_id DEFAULT NEWID(),
  employer_name              VARCHAR(200)    NOT NULL,
  industry                   VARCHAR(120)    NULL,
  sub_industry               VARCHAR(120)    NULL,
  company_size_band          VARCHAR(40)     NULL,
  hq_city                    VARCHAR(80)     NULL,
  hq_state                   VARCHAR(80)     NULL,
  hq_country                 VARCHAR(80)     NULL,
  website_url                VARCHAR(255)    NULL,
  linkedin_url               VARCHAR(255)    NULL,
  is_faang_company           BIT             NOT NULL DEFAULT 0,
  is_non_profit              BIT             NOT NULL DEFAULT 0,
  slu_partnership_type       VARCHAR(60)     NULL,
  slu_partnership_level      VARCHAR(40)     NULL,
  slu_partnership_status     VARCHAR(30)     NULL,
  slu_partnership_start_date DATE            NULL,
  primary_contact_name       VARCHAR(120)    NULL,
  primary_contact_title      VARCHAR(120)    NULL,
  primary_contact_email      VARCHAR(120)    NULL,
  primary_contact_phone      VARCHAR(20)     NULL,
  created_at                 DATETIME        NOT NULL DEFAULT GETDATE(),
  CONSTRAINT PK_employers_1 PRIMARY KEY (employer_id),
  CONSTRAINT chk_slu_partnership_level CHECK (slu_partnership_level IN ('Bronze','Silver','Gold') OR slu_partnership_level IS NULL),
  CONSTRAINT chk_slu_partnership_status CHECK (slu_partnership_status IN ('Active','Inactive','Prospect') OR slu_partnership_status IS NULL),
  CONSTRAINT chk_slu_partnership_type CHECK (slu_partnership_type IN ('Hiring','Academic','Sponsorship','Mentorship','Donor','None') OR slu_partnership_type IS NULL)
);
GO
