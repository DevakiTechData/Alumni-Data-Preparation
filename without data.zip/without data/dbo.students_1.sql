USE SluAlumniDatabase;
GO
CREATE TABLE dbo.students_1 (
  student_id               UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_students_1_id DEFAULT NEWID(),
  slu_banner_id            VARCHAR(20)     UNIQUE,
  first_name               VARCHAR(80)     NOT NULL,
  last_name                VARCHAR(80)     NOT NULL,
  preferred_name           VARCHAR(80)     NULL,
  slu_email                VARCHAR(120)    NOT NULL UNIQUE,
  personal_email           VARCHAR(120)    NULL,
  phone_e164               VARCHAR(20)     NULL,
  program_name             VARCHAR(120)    NOT NULL,
  college_name             VARCHAR(120)    NOT NULL,
  concentration            VARCHAR(120)    NULL,
  start_term               VARCHAR(20)     NOT NULL,
  grad_term                VARCHAR(20)     NULL,
  graduation_year          INT             NULL,
  visa_status              VARCHAR(30)     NOT NULL,
  opt_status               VARCHAR(30)     NOT NULL,
  current_location_city    VARCHAR(80)     NULL,
  current_location_state   VARCHAR(80)     NULL,
  current_location_country VARCHAR(80)     NULL,
  linkedin_url             VARCHAR(255)    NULL,
  CONSTRAINT PK_students_1 PRIMARY KEY (student_id),
  CONSTRAINT chk_visa_status CHECK (visa_status IN ('F1','H1B','PR','Citizen','Other')),
  CONSTRAINT chk_opt_status  CHECK (opt_status  IN ('None','OPT','STEM OPT'))
);
GO
