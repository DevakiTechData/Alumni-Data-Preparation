﻿USE SluAlumniDatabase;
GO
CREATE TABLE dbo.jobs_1 (
  job_id                    UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_jobs_1_id DEFAULT NEWID(), -- PK
  student_id                UNIQUEIDENTIFIER NOT NULL,           -- FK → students_1(student_id)
  employer_id               UNIQUEIDENTIFIER NOT NULL,           -- FK → employers_1(employer_id)
  job_title                 VARCHAR(160)  NOT NULL,              -- e.g., Data Analyst, QA Engineer
  job_family                VARCHAR(80)   NULL,                  -- Analyst / Engineer / PM etc.
  job_level                 VARCHAR(40)   NULL,                  -- Intern / Junior / Mid / Senior
  job_type                  VARCHAR(40)   NOT NULL,              -- Full-time / Contract / Internship
  employment_mode           VARCHAR(20)   NULL,                  -- On-site / Hybrid / Remote
  location_city             VARCHAR(80)   NULL,
  location_state            VARCHAR(80)   NULL,
  location_country          VARCHAR(80)   NULL,
  offer_date                DATE          NULL,
  offer_accept_date         DATE          NULL,
  start_date                DATE          NULL,
  end_date                  DATE          NULL,
  salary_currency           VARCHAR(10)   NULL,                  -- USD / INR / etc.
  salary_base_annual        DECIMAL(12,2) NULL,
  bonus_target_pct          DECIMAL(5,2)  NULL,
  visa_type                 VARCHAR(30)   NULL,                  -- OPT / STEM OPT / H1B / Other / None
  source_channel            VARCHAR(60)   NULL,                  -- Career Fair / Referral / LinkedIn
  created_at                DATETIME      NOT NULL DEFAULT GETDATE(),

  CONSTRAINT PK_jobs_1 PRIMARY KEY (job_id),

  -- Relationships
  CONSTRAINT FK_jobs_1_student FOREIGN KEY (student_id)
      REFERENCES dbo.students_1(student_id)
      ON UPDATE CASCADE
      ON DELETE CASCADE,

  CONSTRAINT FK_jobs_1_employer FOREIGN KEY (employer_id)
      REFERENCES dbo.employers_1(employer_id)
      ON UPDATE CASCADE
      ON DELETE CASCADE,

  -- Validation for job_type and employment_mode
  CONSTRAINT chk_job_type CHECK (
      job_type IN ('Full-time','Contract','Internship') OR job_type IS NULL
  ),
  CONSTRAINT chk_employment_mode CHECK (
      employment_mode IN ('On-site','Hybrid','Remote') OR employment_mode IS NULL
  )
);
GO
