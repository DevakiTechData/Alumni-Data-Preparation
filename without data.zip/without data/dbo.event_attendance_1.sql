﻿USE SluAlumniDatabase;
GO

CREATE TABLE dbo.event_attendance_1 (
  attendance_id           UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_event_att_1_id DEFAULT NEWID(), -- (1) PK
  event_id                UNIQUEIDENTIFIER NOT NULL,           -- (2) FK → events_1(event_id)
  student_id              UNIQUEIDENTIFIER NOT NULL,           -- (3) FK → students_1(student_id)
  registration_status     VARCHAR(20)     NOT NULL,            -- (4) Registered/Waitlisted/Cancelled
  registration_channel    VARCHAR(40)     NULL,                -- (5) Portal/Email/Onsite/Import
  registered_at           DATETIME2       NULL,                -- (6)
  attended                BIT             NOT NULL DEFAULT 0,  -- (7)
  attended_at             DATETIME2       NULL,                -- (8)
  check_in_method         VARCHAR(20)     NULL,                -- (9) QR/Manual/Import
  feedback_score          DECIMAL(3,2)    NULL,                -- (10) 0–5
  feedback_comment        NVARCHAR(MAX)   NULL,                -- (11)
  certificate_issued      BIT             NOT NULL DEFAULT 0,  -- (12) for workshops, etc.
  no_show_reason          VARCHAR(200)    NULL,                -- (13)
  reminder_sent           BIT             NOT NULL DEFAULT 0,  -- (14)
  reminder_sent_at        DATETIME2       NULL,                -- (15)
  created_by_user         VARCHAR(120)    NULL,                -- (16)
  created_at              DATETIME        NOT NULL DEFAULT GETDATE(), -- (17)
  updated_by_user         VARCHAR(120)    NULL,                -- (18)
  updated_at              DATETIME        NULL,                -- (19)
  privacy_level           VARCHAR(20)     NOT NULL DEFAULT 'Internal', -- (20) Public/Internal/Restricted

  CONSTRAINT PK_event_attendance_1 PRIMARY KEY (attendance_id),

  -- Ensure one registration per student per event
  CONSTRAINT UQ_event_attendance_1 UNIQUE (event_id, student_id),

  -- Foreign keys (no cascades to avoid multiple-path issues)
  CONSTRAINT FK_evtatt_event FOREIGN KEY (event_id)
      REFERENCES dbo.events_1(event_id)
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT FK_evtatt_student FOREIGN KEY (student_id)
      REFERENCES dbo.students_1(student_id)
      ON UPDATE NO ACTION ON DELETE NO ACTION,

  -- Controlled values & quality checks
  CONSTRAINT chk_registration_status CHECK (
      registration_status IN ('Registered','Waitlisted','Cancelled')
  ),
  CONSTRAINT chk_checkin_method CHECK (
      check_in_method IN ('QR','Manual','Import') OR check_in_method IS NULL
  ),
  CONSTRAINT chk_privacy_level_evtatt CHECK (
      privacy_level IN ('Public','Internal','Restricted')
  ),
  CONSTRAINT chk_feedback_range CHECK (
      feedback_score IS NULL OR (feedback_score >= 0 AND feedback_score <= 5)
  ),
  -- if attended = 1 then attended_at must be set; if attended = 0 then attended_at must be NULL
  CONSTRAINT chk_attended_timestamp CHECK (
      (attended = 1 AND attended_at IS NOT NULL)
      OR (attended = 0 AND attended_at IS NULL)
  )
);
GO

-- Helpful indexes for analytics
CREATE INDEX IX_event_attendance_1_event    ON dbo.event_attendance_1 (event_id, registration_status, attended);
CREATE INDEX IX_event_attendance_1_student  ON dbo.event_attendance_1 (student_id, attended);
GO
