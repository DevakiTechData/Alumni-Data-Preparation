﻿USE SluAlumniDatabase;
GO

-- If a failed stub exists, drop it cleanly
IF OBJECT_ID('dbo.engagements_1','U') IS NOT NULL
  DROP TABLE dbo.engagements_1;
GO

CREATE TABLE dbo.engagements_1 (
  engagement_id            UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_engagements_1_id DEFAULT NEWID(), -- (1) PK
  alumni_id                UNIQUEIDENTIFIER NOT NULL,            -- (2) FK → alumni_1(alumni_id)
  employer_id              UNIQUEIDENTIFIER NULL,                -- (3) FK → employers_1(employer_id)
  event_id                 UNIQUEIDENTIFIER NULL,                -- (4) FK → events_1(event_id)
  engagement_type          VARCHAR(80)    NOT NULL,              -- (5)
  engagement_subtype       VARCHAR(120)   NULL,                  -- (6)
  engagement_date          DATE           NOT NULL,              -- (7)
  points_awarded           INT            NOT NULL DEFAULT 0,    -- (8)
  hours_contributed        DECIMAL(6,2)   NULL,                  -- (9)
  monetary_value_usd       DECIMAL(12,2)  NULL,                  -- (10)
  channel                  VARCHAR(60)    NULL,                  -- (11)
  satisfaction_rating      DECIMAL(3,2)   NULL,                  -- (12)
  remarks                  NVARCHAR(MAX)  NULL,                  -- (13)
  evidence_url             VARCHAR(255)   NULL,                  -- (14)
  created_by_user          VARCHAR(120)   NULL,                  -- (15)
  created_at               DATETIME       NOT NULL DEFAULT GETDATE(), -- (16)
  status                   VARCHAR(40)    NOT NULL DEFAULT 'Completed', -- (17)
  follow_up_required       BIT            NOT NULL DEFAULT 0,    -- (18)
  follow_up_date           DATE           NULL,                  -- (19)
  privacy_level            VARCHAR(20)    NOT NULL DEFAULT 'Internal', -- (20)

  CONSTRAINT PK_engagements_1 PRIMARY KEY (engagement_id),

  -- FKs (no cascade updates to avoid multiple-path errors)
  CONSTRAINT FK_eng_1_alumni FOREIGN KEY (alumni_id)
      REFERENCES dbo.alumni_1(alumni_id)
      ON UPDATE NO ACTION
      ON DELETE NO ACTION,

  CONSTRAINT FK_eng_1_employer FOREIGN KEY (employer_id)
      REFERENCES dbo.employers_1(employer_id)
      ON UPDATE NO ACTION
      ON DELETE SET NULL,

  CONSTRAINT FK_eng_1_event FOREIGN KEY (event_id)
      REFERENCES dbo.events_1(event_id)
      ON UPDATE NO ACTION
      ON DELETE SET NULL,

  -- Checks
  CONSTRAINT chk_engagement_type CHECK (
      engagement_type IN ('Mentorship','Sponsorship','Talk','Donation','Job Post','Volunteering','Workshop','Panel')
  ),
  CONSTRAINT chk_status CHECK (status IN ('Planned','Completed','Cancelled')),
  CONSTRAINT chk_privacy_level CHECK (privacy_level IN ('Public','Internal','Restricted')),
  CONSTRAINT chk_rating_range CHECK (satisfaction_rating IS NULL OR (satisfaction_rating >= 0 AND satisfaction_rating <= 5)),
  CONSTRAINT chk_nonneg_values CHECK (
      (hours_contributed IS NULL OR hours_contributed >= 0)
      AND (monetary_value_usd IS NULL OR monetary_value_usd >= 0)
      AND points_awarded >= 0
  )
);
GO

-- Helpful indexes
CREATE INDEX IX_engagements_1_alumni   ON dbo.engagements_1 (alumni_id, engagement_date);
CREATE INDEX IX_engagements_1_employer ON dbo.engagements_1 (employer_id, engagement_date);
CREATE INDEX IX_engagements_1_event    ON dbo.engagements_1 (event_id, engagement_date);
GO
