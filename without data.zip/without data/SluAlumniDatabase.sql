CREATE DATABASE SluAlumniDatabase;
GO